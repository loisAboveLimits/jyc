.blox-mega-bar-counter-number-inside .blox-border-bar {
   
  	margin: 0 auto;
}


{% if show_graphic_element == "true" %}
#{{uc_id}} .uepb_graphic_el_wrapper{
  display: block;
}
#{{uc_id}} .uepb_graphic_el {
  display:inline-flex;
  align-items: center;
  justify-content: center;
  overflow:hidden;
}
{% endif %}