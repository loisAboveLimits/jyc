<div class="blox-mega-bar-counter-number-inside" id="{{uc_id}}">
  	
  <div class="blox-bar-row progresseight" role="progressbar" data-goal="{{value}}" data-speed="{{speed}}" data-reveal-on-scroll="{{start_animation_when_in_viewport}}">
        <div class="blox-border-bar">
            <div class="blox-border-progress-bar progress-eight__bar" ></div>
            
        </div>
      <div class="blox-bar-heading">
         {% if (show_graphic_element == "true") %}
             <div class="uepb_graphic_el_wrapper">
               <div class="uepb_graphic_el">
                 {% if graphic_element_source == "icon" %} {{icon_html|raw}} {% endif %}
                 {% if graphic_element_source == "image" %} <img src="{{graphic_image}}" {{graphic_image_attributes|raw}}> {% endif %}
                 {% if graphic_element_source == "text" %} <span>{{graphic_el_text|raw}}</span> {% endif %}
               </div>
             </div>
            {% endif %}
        
          <div class="blox-border-bar-percentage progress-eight__label"> </div>
          <span class="ue-symbol">{{symbol|raw}}</span>
          <div class="blox-bar-title">{{title|raw}}</div>
          
         
        
        
      </div>
	</div>
  	
</div>