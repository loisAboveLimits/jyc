<div class="uc-search-item">
  
  {% if show_categories == "false" %}
  	<a href="{{item.posts.link}}" class="uc-search-item__link" target="{{search_result_open_new_window}}">
  {% else %}
  	<div class="uc-search-item__link">
      
      <a href="{{item.posts.link}}" class="uc-search-item__link-absolute" target="{{search_result_open_new_window}}"></a>
  {% endif %}
    
	{% if item.posts.image is empty %}
    
    	{% if show_custom_default_post_image == "true" %}
    		<img src="{{default_post_image}}" class="uc-search-item__link-image">
    	{% endif %}
    
    {% endif %} 
    
    {% if item.posts.image is not empty %}
     	{% if show_post_image == "true" %}<img src="{{item.posts.image_thumb}}" class="uc-search-item__link-image">{% endif %}
    {% endif %} 
    
    {% if show_categories == "cat" or show_categories == "bytax" or show_categories == "lastlevel" %}
          
        	{% if show_categories == "cat" %}
        		{% set arrcats = item.posts.categories %}
      		{% elseif show_categories == "lastlevel" %}
        		{% set arrcats =  getPostTerms(item.posts.id, cat_tax, false,"last_level",cat_maxterms) %}  
        	{% else %}
        		{% set arrcats =  getPostTerms(item.posts.id, cat_tax, false, "", cat_maxterms) %}        		
			{% endif %}
        
        	<div class="ue-grid-item-category">
              {% for cat in arrcats %}
              	{% if disable_link_in_categories == "true" %}
              		<a href="javascript:void(0);" class="{{item.posts.category_slug}}">{{cat.name|raw}}</a>
              	{% else %}
              		<a href="{{cat.link}}" class="{{item.posts.category_slug}}">{{cat.name|raw}}</a>
              	{% endif %}
              {% endfor %}
        	</div>
        
          {% elseif show_categories == "main" %}
        
        	<div class="ue-grid-item-category">
              
              {% if disable_link_in_categories == "true" %}
              	<a href="javascript:void(0);">{{item.posts.category_name|raw}}</a>
              {% else %}
             	<a href="{{item.posts.category_link}}">{{item.posts.category_name|raw}}</a>
              {% endif %}
              
        	</div>
        	
          {% endif %}
    
     <span class="uc-search-item__link-title">{{item.posts.title|raw}} </span>
    
     {% if show_post_intro == "true" %}<div class="uc-search-item__post-content">{{item.posts.intro_full|truncate(intro_number_of_characters)|raw}}</div>{% endif %}
    
  {% if show_categories == "false" %}
      </a>
  {% else %}
  	</div>
  {% endif %}
  	
</div>