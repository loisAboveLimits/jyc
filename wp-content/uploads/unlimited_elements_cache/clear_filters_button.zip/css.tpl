#{{uc_id}} .uc-button-clear{
  	transition: all .3s;
}
#{{uc_id}} .uc-button-clear{
  {%  if button_style == "flex" %}width:100%;{% endif %}
  align-items:center;
}
#{{uc_id}} .uc-button-clear svg{
  width:1em;
  height:1em;
}
{%  if(uc_inside_editor != "yes") %}
 #{{uc_id}} .uc-button-clear.uc-hidden{
    {% if button_mode == "disabled" %}
        opacity: .5;
  		pointer-events: none;
    {% else %}
        display: none;
    {% endif %}
 }
{% endif %}