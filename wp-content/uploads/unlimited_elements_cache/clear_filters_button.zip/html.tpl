<div id="{{uc_id}}" class="uc-grid-filter uc-button-clear-wrapper" data-filtertype="general" data-generaltype="clear" data-norefresh="true" {{filter_attributes|raw}}>
	
  <button class="uc-button-clear uc-hidden" disabled> {% if show_text == "true" %}{{button_text|raw}}{% endif %}{% if show_icon == "true" %}{{button_icon_html|raw}}{% endif %} </button>
    
</div>