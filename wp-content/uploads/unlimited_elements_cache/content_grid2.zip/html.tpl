<div id="{{uc_id}}" class="uc_post_grid_style_one {{multisource}} {{uc_filtering_addclass}} {{remote_parent.class}} {{uc_dynamic_popup_class}}" {{uc_filtering_attributes|raw}} {{remote_parent.attributes|raw}} data-lightbox="{{image_link_type}}">
  
  {% if show_live_search == "true" and multisource == "uc_items" %}
    <div class="uc_post_grid_style_one_search_wrap">
      <div class="uc_post_grid_style_one_search_container">
        <input class="uc_post_grid_style_one_search_input" type="text" id="{{uc_id}}_input" placeholder="{{live_search_placeholder|raw}}" />
        {% if show_search_icon == "true" %}
          <div class="uc_post_grid_style_one_search_icon">{{search_icon_html|raw}}</div>
          <div class="uc_post_grid_style_one_reset_icon ue-hidden">{{reset_icon_html|raw}}</div>
        {% endif %} 
      </div>{# end uc_post_grid_style_one_search_container #}{##}    
    </div>{# end uc_post_grid_style_one_search_wrap #}{##}
  {% endif %}{# end show_live_search #}{##}
  
  <div class="uc_post_grid_style_one_wrap uc-items-wrapper">
    {% if random_order == "false" %}
      {{put_items()}}
    {% else %}
      {{put_items("shuffle")}}
    {% endif %}
  </div>{# end uc_post_grid_style_one_wrap #}{##}
  
  {% if show_pagination == "true" and multisource == "uc_items" %}
    <div class="uc_post_grid_style_one_prev_button_pagination">
      <div class="uc_post_grid_style_one_prev_button_pagination_wrap">
        {% if show_prev_next_page_button == "true" %}<button class="uc_post_grid_style_one_prev_button uc_post_grid_style_one_pagination_button" aria-label="prev-btn">{{prev_icon_html|raw}}</button>{% endif %}
        <div class="uc_post_grid_style_one_pagination_numbers"></div>
        {% if show_prev_next_page_button == "true" %}<button class="uc_post_grid_style_one_next_button uc_post_grid_style_one_pagination_button" aria-label="next-btn">{{next_icon_html|raw}}</button>{% endif %}
      </div>{# end uc_post_grid_style_one_prev_button_pagination_wrap #}{##}
    </div>{# end uc_post_grid_style_one_prev_button_pagination #}{##}
  {% endif %}{# end show_pagination #}{##}
  
</div>