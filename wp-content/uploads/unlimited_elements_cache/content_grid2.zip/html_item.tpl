{# twig vars #}{##}
{% set buttonTextElem %}{% if item.button_text_override is empty %}{{button_text|raw}}{% else %}{{item.button_text_override|raw}}{% endif %}{% endset %}
{# end twig vars #}{##}

<div class="uc_post_grid_style_one_item ue-item {% if show_pagination == "true" and multisource == "uc_items" %}ue-hidden{% endif %}">
    
  {% if show_image == "true" %}
    <div class="uc_post_grid_style_one_image ue-image-holder">
    {% if image_link == "true" %}
      {% if image_link_type == "true" %}
          <a class="uc_post_grid_style_one-link" href="{{item.link|raw}}" {{item.link_html_attributes|raw}} data-fancybox="gallery" data-src="{{item.image}}">
      {% else %}
          <a class="uc_post_grid_style_one-link" href="{{item.link|raw}}" {{item.link_html_attributes|raw}}>
      {% endif %}
    {% endif %}
            
    <div aria-role="img" aria-label="{{item.image_alt}}"  class="uc_post_image" style="background-image: url({{item.image}});"></div>
    {% if image_link == "true" %}</a>{% endif %}
    </div>
  {% endif %}
  
  <div class="uc_content padding">
    <div class="ue-content-wrapper">
      
      {% if show_title == "true" %}
        {% if title_link == "true" %}<a href="{{item.link|raw}}" {{item.link_html_attributes|raw}}>{% endif %}
        	<{{title_tag}} class="ue-item-title">{{item.title|raw}}</{{title_tag}}>
        {% if title_link == "true" %} </a>{% endif %}
      {% endif %}
      
      {% if show_text == "true" %}<div class="ue-item-text">{{item.content|raw}}</div>{% endif %}      
      {% if show_description == "true" %}<div class="ue-item-descr">{{item.item_description|raw}}</div>{% endif %}
      
    </div>
    
    {% if show_button == "true" %}
    	<div class="uc_post_grid_style_one_button ue-button">
          {% if multisource != "uc_items" %}
            <a class="uc_more_btn {{item.dynamic_popup_link_class|raw}}" 
               {% if item.dynamic_popup_link_class|raw == " uc-open-popup" %}{{item.dynamic_popup_link_attributes|raw}}{% else %} href="{{item.link|raw}}"{% endif %}
               {{item.link_html_attributes|raw}}>{{buttonTextElem}}{% if show_icon_button == "true" %} {{button_icon_html|raw}}{% endif %}
            </a>
          {% else %}
           <a class="uc_more_btn" href="{{item.link|raw}}" {{item.link_html_attributes|raw}}>{{buttonTextElem}}{% if show_icon_button == "true" %}{{button_icon_html|raw}}{% endif %}</a>
          {% endif %}
    	</div>
    {% endif %}
    
  </div>
</div>