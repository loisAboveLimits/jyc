{% set value = ucfunc("get_variable","ucs") %}

<div class="uc-search-filter-wrapper" id="{{uc_id}}-wrapper" >
  <div id="{{uc_id}}" class="uc-search-filter uc-grid-filter" data-filtertype="search" {{filter_attributes|raw}} {%  if custom_links_ending == "true" %}ajaxurladd="postlinkadd=search%3D%0A"{% endif %}> 

      {% if show_label == "true" %} 
      	<div class="uc-search-filter-label">{{label_text|raw}}</div>
      {% endif %}

      <div class="uc-search-filter-input-wrapper">
		
        <input type="text" class="uc-search-filter__input" placeholder="{{input_placeholder|raw}}" value="{{value|e("html_attr")|raw}}">

        {% if show_search_button_or_indicator == "button" %}
            <button type="button" class="uc-search-filter-btn" value="">
              
              <div class="ue-btn-icon">{{button_icon_html|raw}}</div>
              <div class="ue-btn-text">{{search_button_text|raw}}</div>
              
             </button> 
        {% endif %}

        {% if show_search_button_or_indicator == "indicator" %}
              <div class="uc-search-filter-indicator">{{search_indicator_icon_html|raw}}</div>
        {% endif %}  

      </div>

  </div>
</div>