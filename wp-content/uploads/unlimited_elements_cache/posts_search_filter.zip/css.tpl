#{{uc_id}}-wrapper
{
  display:flex;
}

#{{uc_id}}
{
  width:100%;
}
#{{uc_id}} .uc-search-filter__input
{
  width:100%;
  flex-grow:1;
}

#{{uc_id}} .uc-search-filter-btn
{
  display:flex;
  align-items:center;
  flex-grow:0;
  flex-shrink:0;
}

#{{uc_id}} .uc-search-filter-input-wrapper
{
  position: relative;
  display:flex;
  align-items:center;
}


#{{uc_id}} .uc-search-filter-btn .ue-btn-icon
{
  line-height:1em;
}



#{{uc_id}} .uc-search-filter-btn .ue-btn-icon svg
{
  height:1em;
  width:1em;
}

#{{uc_id}} ::-webkit-input-placeholder { /* Edge */
  color: {{placeholder_text_color}};
}

#{{uc_id}} :-ms-input-placeholder { /* Internet Explorer 10-11 */
  color: {{placeholder_text_color}};
}

#{{uc_id}} ::placeholder {
  color: {{placeholder_text_color}};
}

#{{uc_id}} .uc-search-filter-indicator{
	position: absolute;
  	top: 50%;
    transform: translate(0, -50%);
    height: 100%;
  	display: flex;
    align-items: center;
    justify-content: center;
}