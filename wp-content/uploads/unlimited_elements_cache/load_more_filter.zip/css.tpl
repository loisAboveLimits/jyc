#{{uc_id}}.uc-ajax-loading{
	opacity:1 !important;
}

#{{uc_id}}.uc-ajax-loading .uc-filter-load-more__loader{
   display:inline-block !important;
   color:{{loading_color}};
}

#{{uc_id}} .uc-filter-load-more__link{
  align-items: center;
  justify-content: center;
}

{% if(is_infinite == "true" and uc_inside_editor != "yes") %}

#{{uc_id}} .uc-filter-load-more__link{
  visibility:hidden;  
  display: inline-flex;
  align-items: center;
  justify-content: center;
}

#{{uc_id}} .uc-filter-load-more__link-icon{
  display: flex;
  align-items: center;
  justify-content: center;
  line-height: 1em;
  transition: all .3s ease;
}

#{{uc_id}}.uc-button-visible .uc-filter-load-more__link{
   visibility:visible;  
}
{% endif %}

#{{uc_id}}.uc-ajax-loading .uc-filter-load-more__link{
   display:none;  
}

#{{uc_id}}  .uc-filter-load-more__link{
  text-align:center;
}

#{{uc_id}} .uc-load-more-wrapper{
  display:inline-flex;
  align-items:center;
  justify-content:center;
}