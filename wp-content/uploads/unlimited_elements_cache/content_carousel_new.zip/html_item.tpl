<div class="uc_image_carousel_container_holder ue-item">
  {% if show_image == "true" %}
  <div class="uc_image_carousel_placeholder">
    
    <div style="background-image:url({{item.image}});background-position:center; background-repeat:no-repeat;" class="carousel-image"></div>
    
    {% if image_link == "true" %}<a class="ue_img_link" href="{{item.link|raw}}" {{item.link_html_attributes|raw}}></a>{% endif %}
    
    {% if link_type == "true" %}<a class="ue_img_link" href="{{item.image}}" data-e-disable-page-transition="true"></a>{% endif %}
    
  </div>
  {% endif %}

  {% if show_content == "true" %}
  <div class="uc_image_carousel_content content-padding ue-content-holder">
    
    {% if item.source == "content" %}
        <div style="width:100%;">
          {% if show_title == "true" %}
          {% if title_link == "true" %}<a href="{{item.link|raw}}" {{item.link_html_attributes|raw}}>{% endif %}
            <{{title_html_tag}} class="ue-title">{{item.title|raw}}</{{title_html_tag}}>
          {% if title_link == "true" %}</a>{% endif %}
          {% endif %}
        {% if show_intro == "true" %}<div class="ue-text" >{{item.content|raw}}</div>{% endif %}
        </div>
       
    
    
    
    {% if item.link is empty %}
<!-- put your empty case html -->
{% else %}
<!-- put your not empty html here -->

    
    
        {% if show_button == "true" and item.show_button == "true" %}
    		<div class="ue-btn-holder" style="width:100%;">
              {% if multisource != "uc_items" %}
                <a class="ue-btn uc_more_btn ue-dynamic-popup-single {{item.dynamic_popup_link_class|raw}}" {{item.dynamic_popup_link_attributes|raw}}>
              {% else %}
                <a class="ue-btn uc_more_btn"  href="{{item.link|raw}}" {{item.link_html_attributes|raw}}>
              {% endif %}    
                 <div class="ue-btn-inner-wrapper">
                   {% if item.btn_text|raw is empty %}
              		<div class="ue-btn-inner-txt">{{button_text|raw}}</div>
                   {% else %} 
                    <div class="ue-btn-inner-txt">{{item.btn_text|raw}}</div>
                   {% endif %}
                   
                   {% if show_button_icon == "true" %}<div class="ue-btn-inner-icon">{{button_icon_html|raw}}</div>{% endif %}
                   
                 </div>
               </a>
            </div>
        {% endif %}
    
{% endif %}  
    
    
          
    {% endif %}
    
    {% if item.source == "template" %}
        {{putElementorTemplate(item.template_templateid)}}
    {% endif %}
  </div>
  {% endif %}
</div>