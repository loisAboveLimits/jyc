{{ ucfunc("put_docready_start") }}
		
  var objWidget = jQuery('#{{uc_id}}');
  var g_useFancybox = "{{image_link_type}}";
  
  function initCarousel(){
    
    //cloned items fancybox fix
      var objItems = objWidget.find('.ue-item-holder');      
      var itemsNum = objItems.length;

      //set data index for each origin item
      for(let i=0; i<itemsNum; i++){
        var objItem = objItems.eq(i);    
       
        objItem.attr('data-fancy-index', i);        
      }
  
  	objWidget.owlCarousel({
            loop: {{loop}},
			
            paddingType: "{{stage_padding_type}}",   
            rtl:{{rtl}},
            center:{{center}},
			nav: {{show_arrows}},
            navText : ["{{left_arrow_html|raw}}","{{right_arrow_html|raw}}"],                                       
            dotsEach:{{dotseach}},
			{% if make_3d == "true" %}center: true,{% endif %}
            disableNoncenteredLinks: {{disable_non_active_links}},              
            autoplay:{{autoplay}},
            autoplayHoverPause:{{autoplayhoverpause}},
			navigation:false,
            autoplayTimeout:{{autoplay_interval}},
            smartSpeed: {{transition_speed}},  
            scrollToHead: {{scroll_to_head}},
            scrollToHeadOffset: {{scroll_to_head_offset}},        
			responsiveClass: true,
			responsive: {
			       0 : {
						items:{{number_of_items_mobile}},
                        margin: {{margin_mobile}},  
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stage_padding_mobile}},
                        {% endif %}	
                        scrollToHeadForceOnMobile: {{scroll_to_head_forced_on_mobile}},     
					},
					768 : {
						items:{{number_of_items_tablet}},
                        margin: {{margin_tablet}},
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stage_padding_tablet}},
                        {% endif %}	 
					},
					1025 : {
						items:{{number_of_items}},
                        margin: {{margin}}, 
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stage_padding}},
                        {% endif %}	 
					}
			}
		});  
		
          
        {% if change_item_on_click == "true" %}
        var itemsNumber = objWidget.find(".owl-item:not(cloned)").length;       
  		var clonedItemsNumber = objWidget.find(".owl-item.cloned").length / 2; // amount of cloned items on one side
  		var minDeviation = -clonedItemsNumber;
  		var maxDeviation = itemsNumber + (clonedItemsNumber * 2);
  		             
        objWidget.on("click", ".owl-item", function(){
            for(let i = minDeviation; i <= maxDeviation; i++){
              if(jQuery(this).index() - clonedItemsNumber  == i){
                objWidget.trigger('to.owl.carousel', [i, 300, true]);
              }
            }
        });
        {% endif %}
        
        //wait while carousel init
      setTimeout(function(){
        if(g_useFancybox == "false")
        return(false);

        //init fancybox only on non cloned items
        var objAllFancyLink = objWidget.find(".ue-link");
        var fancyLink = objWidget.find(".owl-item:not(.cloned) .ue-link");

        fancyLink.attr("data-fancybox", "gallery")

        fancyLink.fancybox({
            loop: true,
            arrows : true,
            backfocus: false,
        });
        
        //for cloned items find origin items and trigger it
        objClonedItems = objWidget.find(".owl-item.cloned");

        objClonedItems.on('click', function() {

          var objClonedItem = jQuery(this);
          var objClonedItemChild = objClonedItem.find('.ue-item-holder');
          var clickedDataFancyIndex = objClonedItemChild.data('fancy-index');
          var objOriginItem = objWidget.find('.owl-item:not(.cloned) [data-fancy-index='+clickedDataFancyIndex+'] .ue-link');
          var objOriginOwlItem = objOriginItem.parent('.owl-item');

          objOriginItem.trigger('click');

          //do nothing with clicked cloned item https://obu.edu/_resources/ldp/galleries/fancybox/
          return(false);
        });
        
        objAllFancyLink.on("click", function(e){
        	e.preventDefault();
        });
      },400);  
  }
  
  initCarousel();	
    
  objWidget.on("uc_ajax_refreshed",function(){      
     	objWidget.trigger('destroy.owl.carousel');      
        initCarousel();      
  });         
        
  {{ucfunc("put_remote_parent_js","objWidget")}}
    	
{{ ucfunc("put_docready_end") }}