<div id="{{uc_id}}-wrapper">
{% if rtl == "true" %}<div class="uc_dark_carousel" style="direction:rtl;" >{% endif %}
{% if rtl == "false" %}<div class="uc_dark_carousel" style="direction:ltr;" >{% endif %}
   <div class="uc_dark_carousel_box owl-carousel uc-items-wrapper {{remote_parent.class}} {{uc_filtering_addclass}} {{uc_dynamic_popup_class}}" id="{{uc_id}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}}>
      {{put_items()}}
   </div>
</div>
</div>