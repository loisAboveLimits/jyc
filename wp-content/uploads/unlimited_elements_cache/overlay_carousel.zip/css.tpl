#{{uc_id}}-wrapper{
  min-height:1px;
}

#{{uc_id}} .ue-item{
  position:relative;
  overflow:hidden;
}

#{{uc_id}} .uc_paragraph,
#{{uc_id}} .ue-title, 
#{{uc_id}} .ue-btn-wrapper{
  width:100%;
}

#{{uc_id}} .ue-item-icon-wrapper,
#{{uc_id}} .ue-item-image-wrapper{
  display: flex;
}

#{{uc_id}} .ue-item-icon
{
  line-height:1em;
  display:inline-flex;
  justify-content:center;
  align-items:center;
  
}

#{{uc_id}} .ue-item-icon svg{
  height:1em;
  width:1em;
}

.uc_overlay_elegant_carousel *{
	margin:0;
	padding:0px;
	box-sizing: border-box;
}

.uc_overlay_elegant_carousel .uc_elegant_carousel_container_holder{
	position:relative;
	width:100%;
}
.uc_overlay_elegant_carousel .uc_elegant_carousel_container_holder .uc_elegant_carousel_placeholder img{
	width:100%;
    object-fit: cover;
}

#{{uc_id}} .uc_elegant_carousel_placeholder img{
  aspect-ratio: {{image_aspect_ratio}};
}

#{{uc_id}} .uc_elegant_carousel_container_holder .uc_elegant_carousel_content{
	position:absolute;
	left:0px; 
	top:0px; 
    right:0px; 
	bottom:0px; 
	width:100%;	
	overflow:hidden;
    opacity:{{overlay_opacity}};
    transition:1s;
}

#{{uc_id}} .uc_elegant_carousel_container_holder:hover .uc_elegant_carousel_content{
  opacity:{{overlay_opacity_on_hover}};
}

.uc_overlay_elegant_carousel .uc_elegant_carousel_container_holder .uc_elegant_carousel_content .uc_elegant_content_box{
	height:100%;
    display:flex;
    align-items:center;
    justify-content:center;
    flex-direction:column;
}

.uc_overlay_elegant_carousel h2{
	font-size:21px;
}

.uc_overlay_elegant_carousel a.uc_more_btn  {
	display:inline-block;
    text-decoration:none;
}

#{{uc_id}} .owl-dots {
  overflow:hidden;
  display:block!important;
  text-align:{{dot_alignment}};
}

#{{uc_id}} .owl-dot {
  border-radius:50%;
  display:inline-block;
}

#{{uc_id}} .owl-nav .owl-prev,
#{{uc_id}} .owl-nav .owl-next{
    position:absolute;
    display:flex;
  	justify-content: center;
  	align-items: center;
    text-align:center;
}

{% if link_type == "all" %}
  #{{uc_id}} .ue-link-overlay{
    display:block;
    position:absolute;
    top:0;
    left:0;
    right:0;
    bottom:0;
    width:100%;
    height:100%;
  }
{% endif %}	

{% if make_3d == "true" %} 
  #{{uc_id}} .ue-item {
      opacity: 0.3;
      transform: scale3d(0.8, 0.8, 1);
      transition: all 0.3s ease-in-out;
  }

  #{{uc_id}} .active.center .ue-item {
      opacity: 1;
      transform: scale3d(1, 1, 1);
      transition: all 0.3s ease-in-out;
  }
{% endif %}