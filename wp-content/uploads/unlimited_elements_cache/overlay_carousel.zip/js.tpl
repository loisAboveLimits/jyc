jQuery(document).ready(function(){	
function {{uc_id}}_start(){
    
  var objCarousel = jQuery('#{{uc_id}}');
  
  function initCarousel(){
  
    objCarousel.owlCarousel({
                  items: 1,
                  loop: {{loop}},
                  paddingType: "{{stage_padding_type}}",   
                  center:{{center_mode}},
                  autoplay:{{autoplay}},
                  autoplayHoverPause:{{autoplay_hover_pause}},
                  nav: {{show_arrows}},
                  navText : ["{{left_arrow_html|raw}}","{{right_arrow_html|raw}}"],
                  autoplayTimeout:{{autoplay_interval}},
                  smartSpeed: {{transition_speed}},                                                              
                  margin: {{margin}},
                  shuffle:{{shuffle}},
                  responsiveClass: true,
                  autoWidth: {{auto_width}},    
                  dots: {{show_dots}},          
			      responsive: {
			       0 : {
						items:{{number_of_items_mobile}},
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stage_padding_mobile}},
                        {% endif %}
					},
					768 : {
						items:{{number_of_items_tablet}},
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stage_padding_tablet}},
                        {% endif %}	 
					},
					1025 : {
						items:{{number_of_items}},
                        {% if stage_padding_type != "none" %}
                             stagePadding: {{stage_padding}},
                        {% endif %}	 
					}
			}
     });
    
  } 
  
  initCarousel();
  
  {{ucfunc("put_remote_parent_js","objCarousel")}}  
  
  objCarousel.on("uc_ajax_refreshed",function(){      
     	objCarousel.trigger('destroy.owl.carousel');      
        initCarousel();      
  });

}if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});
});