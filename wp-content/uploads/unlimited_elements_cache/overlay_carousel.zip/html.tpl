<div class="uc_overlay_elegant_carousel" style="direction:ltr;" id="{{uc_id}}-wrapper">
        <div class="uc_carousel owl-carousel uc-items-wrapper {{remote_parent.class}} {{uc_filtering_addclass}}" id="{{uc_id}}" {{remote_parent.attributes|raw}} {{uc_filtering_attributes|raw}}>
           	{{put_items()}}
        </div>	
</div>