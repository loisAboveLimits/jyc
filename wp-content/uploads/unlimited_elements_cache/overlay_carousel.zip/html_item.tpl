<div class="uc_elegant_carousel_container_holder ue-item">  
  <div class="uc_elegant_carousel_placeholder"><img src="{{item.image}}" alt="{{item.image_alt}}"></div>
                
  <div class="uc_elegant_carousel_content">
   	<div class="uc_elegant_content_box">
                      
      {% if show_icon == "true" %}
        <div class="ue-item-icon-wrapper">
          <div class="ue-item-icon">{{item.icon_html|raw}}</div>
        </div>
      {% endif %}
      
      {% if show_back_image == "true" %}
        <div class="ue-item-image-wrapper">
          <div class="ue-item-image"><img src="{{item.back_image}}" {{item.back_image_attributes|raw}} /></div>
        </div>
      {% endif %}

      {% if show_title == "true" %}<h2 class="ue-title">{{item.title|raw}}</h2>{% endif %}
      {% if show_text == "true" %}<div class="uc_paragraph">{{item.content|raw}}</div>{% endif %}	

      <div class="ue-btn-wrapper">
        {% if link_type == "button" %}
          <a class="uc_more_btn" href="{{item.link|raw}}" {{item.link_html_attributes|raw}}>{{btn_text|raw}}</a>
        {% endif %}	

        {% if link_type == "all" %}
          <a class="ue-link-overlay" href="{{item.link|raw}}" {{item.link_html_attributes|raw}}></a>
        {% endif %}	
      </div><!-- end ue-btn-wrapper -->
      
    </div><!-- end uc_elegant_content_box -->
  </div><!-- end uc_elegant_carousel_content -->  
</div><!-- end uc_elegant_carousel_container_holder ue-item -->