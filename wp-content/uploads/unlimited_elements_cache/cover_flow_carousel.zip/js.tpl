jQuery(document).ready(function(){
  
function {{uc_id}}_start(){  
  
  var objCoverflow = jQuery("#{{uc_id}}");
  
  function startCoverflow(){
  
  	objCoverflow.show();
      	
    objCoverflow.flipster({
            style: '{{style}}',
          
              {% if style == "infinite-carousel" %}                  
               loop: 2,
               spacing: 0,
              {% else %}  
               loop: {{loop}}, 
               spacing: {{spacing}},                  
              {% endif %}  
                              
            pauseOnHover: {{pauseonhover}},
              
              {% if navigation == "false" %}
                nav: false,
              {% endif %}
               
              {% if navigation == "before" %}
                nav: 'before',
              {% endif %}
              
              {% if navigation == "after" %}
                nav: 'after',
              {% endif %}
                                      
              {% if autoplay == "true" %}
                autoplay: {{autoplay_timeout}},
              {% endif %}                        
                    
            click: {{click}},
            keyboard: {{keyboard}},
            scrollwheel: {{scrollwheel}},
            touch: {{touch}},
            
            {% if start is empty %}
            {% else %} 
                start: {{start|raw}}, 
            {% endif %}	
			
            {% if show_nav_arrows == "true" %}                          
            buttons: true,
            {% elseif show_nav_arrows == "false" %}   
            buttons: false,    
            {% elseif show_nav_arrows == "custom" %} 
            buttons: "custom",                
            buttonPrev: `{{custom_arrow_prev_html|raw}}`,
            buttonNext: `{{custom_arrow_next_html|raw}}`,  
            {% endif %}              
    });
 
  }

  startCoverflow();
  
  objCoverflow.on("uc_ajax_refreshed",function(){
    
    //remove flipster classes from mani container
 	objCoverflow.removeClass("flipster flipster--transform flipster--infinite-carousel flipster--click flipster--active");
    
    var objButtons = objCoverflow.find('.flipster__nav');
    var objArrows = objCoverflow.find('.flipsflipster__button');
    
    //remove buttons and arrows
    objButtons.remove();
    objArrows.remove();
    
    //reinit flipster
    startCoverflow();
    
  });
  
  var objRemoteOptions = {
    	class_items:"ue-coverflow-item",
    	class_active:"flipster__item--current",
    	selector_item_trigger:".flipster__item__content"
  };
 
  {{ucfunc("put_remote_parent_js","objCoverflow","objRemoteOptions")}}
        
    	
}if(jQuery("#{{uc_id}}").length) {{uc_id}}_start(); else
	jQuery( document ).on( 'elementor/popup/show', () => { if(jQuery("#{{uc_id}}").length) {{uc_id}}_start();});
});