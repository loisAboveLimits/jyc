{% if navigation_type == "title" %}
<li class="ue-coverflow-item" data-flip-title="{{item.title}}">
{% endif %}

{% if navigation_type == "index" %}
<li class="ue-coverflow-item" data-flip-title="{{item.item_index}}">
{% endif %}

  
  
  
  {% if show_image == "true" %}
   <div class="ue-item-image">
   {% if item.button_link is not empty %}<a href="{{item.button_link}}" {{item.button_link_html_attributes|raw}}>{% endif %}
      {% if item.image is empty %}
          <img src="{{uc_assets_url}}/placeholder.jpg" class="{{item.item_repeater_class}} ue-coverflow-image">
      {% else %} 
          <img src="{{item.image}}" class="{{item.item_repeater_class}} ue-coverflow-image" {{item.image_attributes|raw}}> 
      {% endif %}	   
   {% if item.button_link is not empty %}</a>{% endif %}
    </div>
   {% endif %}
  
  {% if show_content == "true" %}
   <div class="ue-flip-item-content {{item.item_repeater_class}}-item-content">
     <div class="ue-flip-item-content-inside">
       {% if show_icon == "true" %}<div class="ue-flip-item-icon">{{item.icon_html|raw}}</div>{% endif %}
       {% if show_title == "true" %}<div class="ue-flip-item-title">{{item.title}}</div>{% endif %}
       {% if show_text == "true" %}<div class="ue-flip-item-text">{{item.text|raw}}</div>{% endif %}
       {% if show_button == "true" %}
       	 <div class="ue-item-btn">
           {% if multisource != "uc_items" %}
             <a {{item.button_link_html_attributes|raw}} class="{{button_hover_animation}} ue-dynamic-popup-single {{item.dynamic_popup_link_class|raw}}" {{item.dynamic_popup_link_attributes|raw}}>{{button_text|raw}}</a>
           {% else %}
             <a href="{{item.button_link}}" {{item.button_link_html_attributes|raw}} class="{{button_hover_animation}}">{{button_text|raw}}</a>
       	   {% endif %} 
         </div>
       {% endif %}
       <div class="ue-item-template">{{putElementorTemplate(item.template_templateid)}}</div>
     </div>
  </div>
  {% endif %}
</li>