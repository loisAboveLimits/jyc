{{ ucfunc("put_docready_start") }}

  var objFilter = jQuery("#{{uc_id}}");
  var activeFilters = new ueActiveFiters();

  function onBeforeRefresh(event, arrActiveItems){
    var objGrid = jQuery(this);
    
    activeFilters.putfilterItemsInList(arrActiveItems);
  }

  objFilter.on("init_filter",function(){
      var objGrid = objFilter.data("grid");

      if(!objGrid)
        return(false);

      objGrid.on("update_active_filter_items", onBeforeRefresh);
    
      activeFilters.init("{{uc_id}}", objGrid);    
  });


{{ ucfunc("put_docready_end") }}