<div id="{{uc_id}}" class="ue-active-filters uc-grid-filter" data-filtertype="general" data-generaltype="activefilters" data-norefresh="true" {{filter_attributes|raw}}>
	<div class="ue-active-filters-holder">
      
      {%  if(uc_inside_editor == "yes") %}
       
          <div class="ue-active-filters-item">Black <span class="ue-active-filters-item-remove"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 61 61"><rect x="25" y="-7" width="11" height="75.41" transform="translate(-13 31) rotate(-45)"/><rect x="25" y="-7" width="11" height="75.31" transform="translate(31 -13) rotate(45)"/></svg> </span></div>
          <div class="ue-active-filters-item">White <span class="ue-active-filters-item-remove"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 61 61"><rect x="25" y="-7" width="11" height="75.41" transform="translate(-13 31) rotate(-45)"/><rect x="25" y="-7" width="11" height="75.31" transform="translate(31 -13) rotate(45)"/></svg> </span></div>
          <div class="ue-active-filters-item">Red <span class="ue-active-filters-item-remove"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 61 61"><rect x="25" y="-7" width="11" height="75.41" transform="translate(-13 31) rotate(-45)"/><rect x="25" y="-7" width="11" height="75.31" transform="translate(31 -13) rotate(45)"/></svg> </span></div>
      
      {% endif %}	
      
  	</div>
</div>