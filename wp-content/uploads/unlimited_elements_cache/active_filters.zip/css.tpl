#{{uc_id}}{
  min-height:1px;
}
#{{uc_id}} .ue-active-filters-item-remove{
	cursor: pointer;
}
#{{uc_id}} .ue-active-filters-item-remove{
	cursor: pointer;
}
#{{uc_id}} .ue-active-filters-holder{
  display:flex;
}

#{{uc_id}} .ue-active-filters-item{
    display: flex;
    align-items: center;
    justify-content: center;
}
#{{uc_id}} .ue-active-filters-item-remove{
    display: flex;
    align-items: center;
    justify-content: center;
    fill:white;
}

#{{uc_id}} .ue-active-filters-item-remove svg{
  width:1em;
  height:1em;
}