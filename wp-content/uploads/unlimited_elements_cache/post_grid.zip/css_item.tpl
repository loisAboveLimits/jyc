{% if show_post_counter_index == "true" %}
#{{item.item_id}} .ue_p_title::before{
 content:"{{ "%02d"|format(item.item_index) }}";
}
{% endif %}


#{{item.item_id}} [href="javascript:void(0)"]{
  cursor: unset;
}