<div class="uc_post_grid_style_one{{uc_filtering_addclass}}{{remote_parent.class}} {{uc_dynamic_popup_class}}" id="{{uc_id}}" {{uc_filtering_attributes|raw}} {{remote_parent.attributes|raw}}>
		<div class="uc_post_grid_style_one_wrap ue_post_grid uc-items-wrapper">
			{{put_items()}}
		</div>
	</div>


{% if show_empty_message == "true" %}

  <div id="{{uc_id}}_empty_message" class="ue-no-posts-found" {% if uc_num_items > 0 %} style="display:none" {% endif %}>{{no_posts_found|raw}}</div>

{% endif %}